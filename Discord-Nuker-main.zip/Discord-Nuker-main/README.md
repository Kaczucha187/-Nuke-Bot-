# Discord-Nuker

New Discord Nuker - Updated Features

**Features:**

- Webhook Creater/Spammer
- Deletes All Channels/Roles
- Spam Creates Roles/Channels
- Prunes Server of members! (better for big servers) 
- Kicks any members possible
- Multi Token Capability
- Changes Server Name
- Gives everyone role admin perms

**Requirements:**

- Admin within the server! 
- Node.js | https://nodejs.org/en/ 


**How to Use:**

- Make sure all requirements are installed by Running Install Bat
- Put user token within tokens file (can have multiple)
- Run Start Bat 
- Execute Nuke command within a server you have perms! 

![Nuke](https://user-images.githubusercontent.com/59532064/118379656-d28b3f00-b5d3-11eb-8e79-4dde120fa6f4.PNG)
